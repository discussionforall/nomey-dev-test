export const fallbackLng = "en";
export const languages = [fallbackLng, "de"];
export const defaultNS = "translation";
export const cookieName = "nomey-i18next";
