export { emailService } from "./services/email-service";

// Export types and template types for emails
export * from "./types";
export * from "./types/templates";
