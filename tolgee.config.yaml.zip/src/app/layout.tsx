import { RealTimeComponent } from './components/RealTimeComponent';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html>
      <body>
        {children}
        <RealTimeComponent />
      </body>
    </html>
  );
}