"use client"
// components/RealTimeUpdates.tsx
import { useSSE } from '@/hooks/useSSE';
import { useEffect, useState } from 'react';
import { toast } from 'react-hot-toast';

export function RealTimeUpdates() {
  const [updates, setUpdates] = useState<any[]>([]);
  const { clientId, addEventHandler, removeEventHandler } = useSSE();
  
  useEffect(() => {
    const handleNotification = (data: any) => {
      toast.success(data.message);
      setUpdates(prev => [...prev, { type: 'notification', ...data }]);
    };

    const handleUpdate = (data: any) => {
      setUpdates(prev => [...prev, { type: 'update', ...data }]);
    };

    addEventHandler('notification', handleNotification);
    addEventHandler('update', handleUpdate);
    
    return () => {
      removeEventHandler('notification');
      removeEventHandler('update');
    };
  }, [addEventHandler, removeEventHandler]);

  return (
    <div className="fixed bottom-4 right-4 w-72 bg-white shadow-lg rounded-lg p-4 border border-gray-200">
      <h3 className="font-bold mb-2">Real-Time Updates</h3>
      <div className="text-xs mb-2">Client ID: {clientId}</div>
      
      <div className="space-y-2 max-h-60 overflow-y-auto">
        {updates.map((update, index) => (
          <div key={index} className="p-2 text-sm border-b border-gray-100">
            <div className="font-medium">{update.type}</div>
            <div>{update.message || JSON.stringify(update)}</div>
            <div className="text-xs text-gray-500">
              {new Date(update.timestamp).toLocaleTimeString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}