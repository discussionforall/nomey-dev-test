"use client"
import { useSSE } from '@/hooks/useSSE';
import { useEffect } from 'react';

export function RealTimeComponent() {
  const { 
    clientId, 
    status,
    isConnected,
    addHandler,
    removeHandler,
    reconnect 
  } = useSSE({ debug: true });

  useEffect(() => {
    const handleNotification = (data: any) => {
      console.log('Notification:', data);
    };
    
    const handleUpdate = (data: any) => {
      console.log('Update:', data);
    };

    addHandler('notification', handleNotification);
    addHandler('update', handleUpdate);

    return () => {
      removeHandler('notification');
      removeHandler('update');
    };
  }, [addHandler, removeHandler]);

  return (
    <div>
      <h2>Real-Time Updates</h2>
      <p>Status: 
        {status === 'connecting' && <span style={{ color: 'orange' }}>Connecting...</span>}
        {status === 'connected' && <span style={{ color: 'green' }}>Connected</span>}
        {status === 'disconnected' && <span style={{ color: 'red' }}>Disconnected</span>}
      </p>
      
      {status === 'disconnected' && (
        <div>
          <p style={{ color: 'red' }}>Connection lost</p>
          <button onClick={reconnect}>Reconnect</button>
        </div>
      )}
      
      <p>Client ID: {clientId || 'Not connected'}</p>
    </div>
  );
}