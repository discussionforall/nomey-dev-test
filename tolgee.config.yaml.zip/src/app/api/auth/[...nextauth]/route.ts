import { handlers } from "@/features/auth";

export const { GET, POST } = handlers;
