import { NextRequest } from 'next/server';

const clients = new Map<string, ReadableStreamDefaultController>();

export async function GET(request: NextRequest) {
  // Handle CORS for SSE
  const headers = new Headers({
    'Content-Type': 'text/event-stream',
    'Connection': 'keep-alive',
    'Cache-Control': 'no-cache, no-transform',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
  });

  // Generate client ID
  const clientId = Date.now().toString();

  const stream = new ReadableStream({
    start(controller) {
      clients.set(clientId, controller);
      
      // Send initial connection message
      controller.enqueue(`data: ${JSON.stringify({ type: 'connected', clientId })}\n\n`);
      
      // Heartbeat
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(`: heartbeat\n\n`);
        } catch (e) {
          clearInterval(heartbeat);
        }
      }, 3000);
      
      // Cleanup
      request.signal.addEventListener('abort', () => {
        clearInterval(heartbeat);
        clients.delete(clientId);
        controller.close();
      });
    }
  });

  return new Response(stream, { headers });
}