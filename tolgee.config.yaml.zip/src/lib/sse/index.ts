    // lib/sse.ts
import { sendEventToClient, broadcastEvent } from '@/app/api/sse/route';

export class SSEManager {
  static sendToClient(clientId: string, event: string, data: any) {
    sendEventToClient(clientId, event, data);
  }

  static broadcast(event: string, data: any) {
    broadcastEvent(event, data);
  }
}