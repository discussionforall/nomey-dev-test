"use client"
import { useEffect, useCallback, useState, useRef } from 'react';

export function useSSE(options: { debug?: boolean } = {}) {
  const { debug = false } = options;
  const [eventSource, setEventSource] = useState<EventSource | null>(null);
  const [status, setStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');
  const [clientId, setClientId] = useState<string | null>(null);
  const eventHandlers = useRef<Record<string, (data: any) => void>>({});

  const log = useCallback((...args: any[]) => {
    if (debug) console.log('[useSSE]', ...args);
  }, [debug]);

  const connect = useCallback(() => {
    log('Attempting to connect...');
    setStatus('connecting');

    try {
      const es = new EventSource('/api/sse');

      es.onopen = () => {
        log('Connection opened');
        setStatus('connected');
      };

      es.onerror = () => {
        log('Connection error');
        setStatus('disconnected');
        es.close();
      };

      es.addEventListener('message', (event) => {
        try {
          const data = JSON.parse(event.data);
          log('Received message:', data);

          if (data.type === 'connected') {
            setClientId(data.clientId);
            setStatus('connected');
          }

          if (data.type && eventHandlers.current[data.type]) {
            eventHandlers.current[data.type]?.(data);
          }
        } catch (err) {
          log('Error parsing message:', err);
        }
      });

      setEventSource(es);
      return es;
    } catch (err) {
      log('Connection failed:', err);
      setStatus('disconnected');
      return null;
    }
  }, [log]);

  useEffect(() => {
    const es = connect();

    return () => {
      log('Cleaning up...');
      if (es) es.close();
      setEventSource(null);
      setStatus('disconnected');
    };
  }, [connect, log]);

  const addHandler = useCallback((type: string, handler: (data: any) => void) => {
    eventHandlers.current[type] = handler;
    log(`Added handler for ${type}`);
  }, [log]);

  const removeHandler = useCallback((type: string) => {
    delete eventHandlers.current[type];
    log(`Removed handler for ${type}`);
  }, [log]);

  return {
    clientId,
    status,
    isConnected: status === 'connected',
    addHandler,
    removeHandler,
    reconnect: connect,
  };
}